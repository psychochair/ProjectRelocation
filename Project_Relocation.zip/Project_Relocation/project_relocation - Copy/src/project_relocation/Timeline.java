/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_relocation;

/**
 *
 * @author sandr
 */
public class Timeline {
    
    private Orders[] orders;
    
    public Timeline(){
        
    }
    
    public Orders[] getOrders() {
        return orders;
    }

    public void addOrder(Orders[] orders) {
      
    } 
    
    public void modifyOrder(Orders[] orders) {
      
    } 
    
    public void swapOrder(Orders[] orders) {
      
    } 
    
    public void removeOrder(Orders[] orders) {
      
    } 
}
